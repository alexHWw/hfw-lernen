// Offline-Speicher: Die App funktioniert nach dem ersten Öffnen auch ohne Internet.
// Strategie: Antwort aus dem Speicher sofort liefern und im Hintergrund aktualisieren.
const CACHE = 'hfw-lernapp-v4';

// Beim Installieren sofort alles speichern: Startseite und alle Programmdateien (JS, CSS),
// die in index.html stehen. So geht die App schon nach dem ersten Öffnen offline.
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then(async (c) => {
      await c.addAll(['./', './index.html', './manifest.webmanifest', './icon.svg']);
      const html = await (await c.match('./index.html')).text();
      const dateien = [...html.matchAll(/(?:src|href)="(\.\/assets\/[^"]+)"/g)].map((m) => m[1]);
      await c.addAll(dateien);
    }),
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;

  // Seitenaufrufe: zuerst Internet (neueste Version), sonst gespeicherte Seite
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const kopie = res.clone();
          caches.open(CACHE).then((c) => c.put('./index.html', kopie));
          return res;
        })
        .catch(() => caches.match('./index.html')),
    );
    return;
  }

  // Dateien (JS, CSS, Bilder): aus dem Speicher, im Hintergrund aktualisieren
  event.respondWith(
    caches.open(CACHE).then(async (c) => {
      const gespeichert = await c.match(req);
      const netz = fetch(req)
        .then((res) => {
          if (res.ok) c.put(req, res.clone());
          return res;
        })
        .catch(() => gespeichert);
      return gespeichert || netz;
    }),
  );
});
